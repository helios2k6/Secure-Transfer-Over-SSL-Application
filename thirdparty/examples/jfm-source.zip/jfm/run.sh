java -cp classes/ org.jfm.main.Main

